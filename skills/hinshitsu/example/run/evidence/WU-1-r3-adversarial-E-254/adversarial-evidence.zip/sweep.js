// C3 sweep. Auditor's own arithmetic (BigInt, written without reading the page's function as a model: remainder test for the half cent, repeated dealing of cents for the payments).
const { launch, URL } = require('./lib');
function expected(billStr, tip, people) {
  const [w, d = ''] = billStr.split('.');
  const cents = BigInt(w) * 100n + BigInt((d + '00').slice(0, 2));
  const x = cents * BigInt(tip); let tipC = x / 100n; if (x % 100n >= 50n) tipC += 1n;
  const total = cents + tipC;
  const pays = Array(people).fill(0n); let left = total; const each = left / BigInt(people);
  for (let i = 0; i < people; i++) { pays[i] = each; left -= each; }
  for (let i = 0; left > 0n; i++, left--) pays[i] += 1n;
  const m = c => (c / 100n) + '.' + String(c % 100n).padStart(2, '0');
  const hi = pays.filter(p => p === pays[0]).length, lo = people - hi;
  const line = (n, c) => n === 1 ? `1 person pays ${m(c)}` : `${n} people pay ${m(c)} each`;
  const lines = [`Bill total: ${m(cents)}`, `Tip percent: ${tip}`, `Number of people: ${people}`, `Tip amount: ${m(tipC)}`, `Total with tip: ${m(total)}`];
  if (lo === 0) lines.push(line(people, pays[0])); else { lines.push(line(hi, pays[0]), line(lo, pays[people - 1]), 'Your group decides who pays the higher amount.'); }
  return lines;
}
(async () => {
  const shard = process.argv[2];
  const b = await launch(); const page = await b.newPage(); await page.goto(URL);
  let n = 0, bad = 0; const fails = [];
  const read = () => page.evaluate(() => ({ r: [...document.querySelectorAll('#result p')].map(p => p.textContent), e: ['bill', 'tip', 'people'].map(i => document.getElementById(i + '-error').textContent).join('|'), t: document.getElementById('result').innerText }));
  const setKeys = async (id, text) => { await page.focus('#' + id); await page.keyboard.press('Control+a'); await page.keyboard.type(text); };
  const check = async (bill, tip, people) => {
    const got = await read(); const exp = expected(bill, tip, people); n++;
    // own invariants on the page's own text
    let inv = '';
    if (JSON.stringify(got.r) !== JSON.stringify(exp)) { bad++; if (fails.length < 40) fails.push({ bill, tip, people, got: got.r, exp, err: got.e }); }
  };
  const cents = (lo, hi) => { const a = []; for (let c = lo; c <= hi; c++) a.push(Math.floor(c / 100) + '.' + String(c % 100).padStart(2, '0')); return a; };
  if (shard === 'A' || shard === 'B' || shard === 'C' || shard === 'D') {
    const tip = { A: 0, B: 15, C: 18, D: 20 }[shard];
    await setKeys('tip', String(tip)); await setKeys('people', '1');
    for (const bill of cents(1, 5000)) { await setKeys('bill', bill); await check(bill, tip, 1); }
  } else if (shard === 'E' || shard === 'F') {
    await setKeys('tip', '18');
    for (let p = (shard === 'E' ? 1 : 7); p <= (shard === 'E' ? 6 : 12); p++) { await setKeys('people', String(p)); for (const bill of cents(1, 500)) { await setKeys('bill', bill); await check(bill, 18, p); } }
  } else if (shard === 'S') {
    for (const [bill, tip, p] of [['10.00', '0', '3'], ['1000000.00', '100', '100'], ['0.01', '0', '100']]) {
      await page.goto(URL); await setKeys('bill', bill); await setKeys('tip', tip); await setKeys('people', p); await check(bill, +tip, +p);
      console.log('spot', bill, tip, p, JSON.stringify((await read()).r));
    }
    // one-decimal form of every 10-cent bill 0.1..50.0 at tip 18, 1 person (not in C3's list; C4 format allows 1 decimal digit)
    await page.goto(URL); await setKeys('tip', '18'); await setKeys('people', '1'); let n1 = 0, bad1 = 0; const f1 = [];
    for (let c = 10; c <= 5000; c += 10) { const bill = Math.floor(c / 100) + '.' + (c % 100) / 10; await setKeys('bill', bill); const got = await read(); const exp = expected(bill, 18, 1); n1++; if (JSON.stringify(got.r) !== JSON.stringify(exp)) { bad1++; if (f1.length < 3) f1.push({ bill, got: got.r, exp }); } }
    console.log(`one-decimal bills: cases=${n1} mismatches=${bad1}`, JSON.stringify(f1));
    // comma form, every bill 0,01..5,00 tip 18 people 3
    await setKeys('people', '3'); let n2 = 0, bad2 = 0;
    for (const bill of cents(1, 500)) { await setKeys('bill', bill.replace('.', ',')); const got = await read(); n2++; if (JSON.stringify(got.r) !== JSON.stringify(expected(bill, 18, 3))) bad2++; }
    console.log(`comma bills: cases=${n2} mismatches=${bad2}`);
  }
  console.log(`shard ${shard}: cases=${n} mismatches=${bad}`); for (const f of fails) console.log(JSON.stringify(f));
  await b.close();
})().catch(e => { console.error('ERR', e); process.exit(1); });
