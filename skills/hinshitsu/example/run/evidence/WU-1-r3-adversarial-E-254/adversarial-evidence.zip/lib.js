const { chromium } = require('playwright');
const path = '/home/ubuntu/audit/devin/skills/hinshitsu/example/run/review/index.html';
const URL = 'file://' + path;
const EXE = '/opt/.devin/chrome/chrome/linux-156.0.8078.47/chrome-linux64/chrome';
async function launch(opts = {}) {
  return chromium.launch({ executablePath: EXE, headless: opts.headless !== false, args: opts.args || [] });
}
async function state(page) {
  return page.evaluate(() => {
    const t = id => document.getElementById(id).textContent;
    const ps = [...document.querySelectorAll('#result p')].map(p => p.textContent);
    return { bill: t('bill-error'), tip: t('tip-error'), people: t('people-error'), result: ps,
      resultText: document.getElementById('result').innerText };
  });
}
const esc = s => [...s].map(c => { const k = c.codePointAt(0); return (k < 0x20 || k > 0x7e) ? 'U+' + k.toString(16).toUpperCase().padStart(4, '0') : c; }).join(' ').replace(/(?<=[ -~]) (?=[ -~])/g, '');
// real keyboard entry: focus by click, clear, insert text (fires real input events), for chars not on a keyboard insertText is what an IME or paste does
async function typeInto(page, id, text) {
  await page.click('#' + id);
  await page.keyboard.press('Control+a');
  await page.keyboard.press('Delete');
  const ascii = /^[\x20-\x7e]*$/.test(text);
  if (ascii) await page.keyboard.type(text); else await page.keyboard.insertText(text);
}
function fmt(s) { return `bill-msg=${JSON.stringify(s.bill)} tip-msg=${JSON.stringify(s.tip)} people-msg=${JSON.stringify(s.people)} result=${JSON.stringify(s.result)}`; }
module.exports = { launch, state, typeInto, URL, path, esc, fmt, EXE };
