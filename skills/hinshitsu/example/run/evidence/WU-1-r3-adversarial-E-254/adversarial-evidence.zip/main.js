const { launch, state, typeInto, URL, path, esc, fmt } = require('./lib');
const fs = require('fs');
(async () => {
  const b = await launch(); const ctx = await b.newContext(); const page = await ctx.newPage();
  // ---- C1: request log
  const cdp = await ctx.newCDPSession(page); await cdp.send('Network.enable'); const reqs = [];
  cdp.on('Network.requestWillBeSent', e => reqs.push(e.request.url));
  const errs = []; page.on('console', m => errs.push('console.' + m.type() + ': ' + m.text())); page.on('pageerror', e => errs.push('pageerror: ' + e.message));
  await page.goto(URL); await page.waitForTimeout(1500);
  console.log('== C1 requests:', reqs.length, JSON.stringify(reqs));
  const src = fs.readFileSync(path, 'utf8');
  console.log('external refs in source (src=, href=, url(, @import, import, fetch, XMLHttpRequest, WebSocket, sendBeacon):', JSON.stringify(src.match(/src=|href=|url\(|@import|\bimport\b|fetch|XMLHttpRequest|WebSocket|sendBeacon|<link|<img|<iframe/g)));
  // ---- first open
  console.log('== C4 first open:', fmt(await state(page)), 'values=', JSON.stringify(await page.evaluate(() => [...document.querySelectorAll('input')].map(i => i.value))), 'body=', JSON.stringify(await page.locator('body').innerText()));
  // ---- C2 tests
  console.log('== C2');
  const full = async (bill, tip, people) => { await page.goto(URL); await typeInto(page, 'bill', bill); await typeInto(page, 'tip', tip); await typeInto(page, 'people', people); const s = await state(page); console.log(JSON.stringify([esc(bill), esc(tip), esc(people)]), fmt(s)); return s; };
  for (const c of [['100.00', '18', '4'], ['0.30', '15', '1'], ['10.10', '15', '1'], ['12.25', '18', '1'], ['0100.5', '007', '02'], ['0.01', '0', '1'], ['1000000.00', '100', '100'], ['1000000', '0', '1'], ['0.01', '100', '100'], ['0.03', '50', '2'], ['1', '1', '1'], ['99.99', '100', '99'], ['000000000000000000000000000000000000000000000000000000000001.50', '000000000000000000000000000000000000000000000000000000000000018', '0000000000000000000000000000000000000000000000000000000000000004']]) await full(...c);
  console.log('innerText of result for 10.00/0/3:'); await full('10.00', '0', '3'); console.log(JSON.stringify(await page.locator('#result').innerText()));
  // ---- C4 inputs: field under test typed and left with Tab; other 2 fields valid
  console.log('== C4 bill inputs (tip 18, people 4). F = while focused, L = after leaving');
  const one = async (id, text) => {
    await page.goto(URL);
    const others = { bill: '100.00', tip: '18', people: '4' };
    for (const k of Object.keys(others)) if (k !== id) await typeInto(page, k, others[k]);
    await typeInto(page, id, text);
    const held = await page.inputValue('#' + id);
    const f = await state(page); await page.keyboard.press('Tab'); await page.click('h1'); const l = await state(page);
    const show = s => (s[id] ? 'MSG ' + JSON.stringify(s[id]) : 'no-msg') + ' / ' + (s.result.length ? 'RESULT ' + s.result[0] + (id !== 'bill' ? ' | ' + s.result[1] + ' | ' + s.result[2] : '') : 'no-result');
    console.log(`${id} [${esc(text)}]${held !== text ? ' (field holds [' + esc(held) + '])' : ''}\n     F: ${show(f)}\n     L: ${show(l)}`);
  };
  const bills = ['', ' ', 'abc', '1,000.00', '1.000,00', '1e3', '10.', '10,', '.5', ',5', '.', '$5', '5$', '\u20AC5', '5 \u20AC', '-5', '\u22125', '+5', '0', '0.00', '0,0', '00', '1000000.00', '1000000.01', '1000001', '1000000,1', '9999999', '1.234', '1,234', '12.505', '1.2.3', '1..2', '1,,2', '1.,2', '12.50', '12,50', '12.5', '0100.5', ' 12.50 ', '\t12.50\u00A0', '\u200B12.50\u200B', '\uFEFF12.50', '12\u200B.50', '12 .50', '1 2', '1\u00A0000', '1\u202F000,00', "1'000.00", '1_000', '\uFF11\uFF12\uFF0E\uFF15\uFF10', '\uFF11\uFF12\uFF0C\uFF15\uFF10', '\u0661\u0662\u066B\u0665\u0660', '\u0661\u0662.\u0665\u0660', '\u06F1\u06F2\u066B\u06F5\u06F0', '\u0661\u066C\u0660\u0660\u0660', '\u0967\u0968', '\u09E7\u09E8', '\u0E51\u0E52', '\uD835\uDFCF\uD835\uDFD0', '\u2167', '\u4E00\u4E8C', '\u00BD', '1\u00BD', '12\u300250', '12\uFF6150', '12\u00B750', '12\u06D450', '0x10', '0b11', '1_0', 'Infinity', 'NaN', '1/2', '12.50%', '(12.50)', '12.50-', '--5', '1e-2', '12:50', '<b>1</b>', '"><script>alert(1)</script>', '12.50\u0000', '\u000112.50', '12.50\u0085', '12.50\u001F', '12.50\u007F', '\u060012.50', '12.50\u06DD', '\u070F12.50', '12.50\u1680', '12.50\uFE0F', '12.50\u20E3', '12.50\u0301', '12.50\u3164', '12.50\u2800', '12.50\uFFFC', '12.50\uFFFD', '\uD83D\uDE0012.50', '12.50\uD83D', '\uDC0012.50', '\u202E05.21', '\u202E05.21\u202C', '12.5\u200D0', '1\u034F2'];
  for (const t of bills) await one('bill', t);
  console.log('== C4 tip inputs (bill 100.00, people 4)');
  for (const t of ['', '0', '00', '100', '0100', '101', '1000', '-1', '-0', '+4', '4.', '4,', '18.0', '18,5', '1e1', '18%', '18 %', ' 18 ', 'abc', '1 8', '\uFF11\uFF18', '\u0661\u0668', '\u06F1\u06F8', '\u0967\u096E', '\u00B2', '\u2460', '0x12', '١٨٪', '18\u200F', '99999999999999999999999', '0.0', '.5']) await one('tip', t);
  console.log('== C4 people inputs (bill 100.00, tip 18)');
  for (const t of ['', '0', '00', '1', '01', '100', '101', '-1', '+4', '4.', '4,0', '4.0', '1e1', '2.5', 'four', ' 4 ', '\uFF14', '\u0664', '\u06F4', '\u2463', '\u2163', '4 people', '1e2', '0x4', '4\u200B', '4\u00AD4']) await one('people', t);
  // ---- state sequences
  console.log('== C4 sequences');
  await page.goto(URL);
  await page.click('#bill'); console.log('click empty bill:', fmt(await state(page)));
  await page.keyboard.press('Tab'); console.log('Tab (left bill empty):', fmt(await state(page)), 'aria-invalid bill=', await page.getAttribute('#bill', 'aria-invalid'));
  await page.keyboard.press('Tab'); await page.keyboard.press('Tab'); console.log('Tab x2:', fmt(await state(page)));
  await page.goto(URL);
  await typeInto(page, 'people', '4'); await typeInto(page, 'tip', '18'); console.log('people, tip filled, bill untouched:', fmt(await state(page)));
  await page.click('#bill'); await page.keyboard.type('1'); console.log('typed 1 in bill:', (await state(page)).result.length, 'lines');
  await page.keyboard.press('Backspace'); console.log('backspace -> empty, typed-in:', fmt(await state(page)));
  await page.keyboard.type('7'); await page.keyboard.press('Control+z'); console.log('type 7 then ctrl+z:', JSON.stringify(await page.inputValue('#bill')), fmt(await state(page)));
  // recompute on every change
  await page.goto(URL); await typeInto(page, 'tip', '18'); await typeInto(page, 'people', '4'); await page.click('#bill');
  for (const ch of '100.00') { await page.keyboard.type(ch); const s = await state(page); console.log('  bill=' + JSON.stringify(await page.inputValue('#bill')), s.bill ? 'MSG' : '', s.result.length ? s.result[0] + ' / ' + s.result[4] : 'no-result'); }
  // paste
  console.log('== paste (clipboard API, Ctrl+V)');
  await ctx.grantPermissions(['clipboard-read', 'clipboard-write']);
  const paste = async (id, text) => { await page.evaluate(t => navigator.clipboard.writeText(t), text); await page.click('#' + id); await page.keyboard.press('Control+a'); await page.keyboard.press('Control+v'); return page.inputValue('#' + id); };
  await page.goto(URL); await typeInto(page, 'tip', '18'); await typeInto(page, 'people', '4');
  for (const t of ['12.50\n', '12.50\r\n13.50', '12\n.50', '  12.50  ', '0'.repeat(62) + '12345', ' '.repeat(64) + '12.50', '12.50' + ' '.repeat(59) + 'USD', '12.5' + ' '.repeat(60) + '0', '1000000.00'.padStart(64, '0') + '9', '\u200B'.repeat(70) + '5']) { const held = await paste('bill', t); const s = await state(page); console.log(`  clipboard [${esc(t).slice(0, 80)}] (${t.length} units) -> field holds ${held.length} units [${esc(held).slice(0, 60)}] :: ${s.bill ? 'MSG ' + s.bill : 'no-msg'} / ${s.result.length ? s.result[0] : 'no-result'}`); }
  // ---- C5
  console.log('== C5');
  for (const w of [320, 360, 768, 1280]) {
    await page.setViewportSize({ width: w, height: 800 });
    for (const [label, vals] of [['first', null], ['result2', ['10.00', '0', '3']], ['max', ['1000000.00', '100', '100']], ['errors', ['x'.repeat(64), 'W'.repeat(64), '9'.repeat(64)]]]) {
      await page.goto(URL);
      if (vals) { await typeInto(page, 'bill', vals[0]); await typeInto(page, 'tip', vals[1]); await typeInto(page, 'people', vals[2]); await page.keyboard.press('Tab'); }
      const m = await page.evaluate(() => { const iw = window.innerWidth, cw = document.documentElement.clientWidth; const wide = [...document.querySelectorAll('*')].filter(e => { const r = e.getBoundingClientRect(); return r.width > iw + 0.01 || r.right > iw + 0.01 || r.left < -0.01; }).map(e => e.tagName + '#' + e.id); window.scrollTo(1000, 0); return { iw, cw, docScrollW: document.documentElement.scrollWidth, bodyScrollW: document.body.scrollWidth, scrollX: window.scrollX, wide, inputScroll: [...document.querySelectorAll('input')].map(i => i.scrollWidth + '/' + i.clientWidth) }; });
      console.log(`  w=${w} ${label}:`, JSON.stringify(m));
      await page.screenshot({ path: `w${w}_${label}.png`, fullPage: true });
    }
  }
  await page.setViewportSize({ width: 1280, height: 800 }); await page.goto(URL);
  console.log('  markup:', JSON.stringify(await page.evaluate(() => ({ labels: [...document.querySelectorAll('label')].map(l => ({ for: l.htmlFor, text: l.textContent, vis: l.getBoundingClientRect().height > 0, pointsAtInput: !!document.getElementById(l.htmlFor) })), inputs: [...document.querySelectorAll('input')].map(i => ({ id: i.id, inputmode: i.getAttribute('inputmode'), autocomplete: i.getAttribute('autocomplete'), type: i.type, maxlength: i.getAttribute('maxlength') })), alerts: [...document.querySelectorAll('.error')].map(e => e.id + ':' + e.getAttribute('role')), result: document.getElementById('result').getAttribute('role') + '/' + document.getElementById('result').getAttribute('aria-live') }))));
  // mutation counts across many sequences
  const watch = () => page.evaluate(() => { window.__n = {}; window.__obs = []; for (const k of ['bill-error', 'tip-error', 'people-error', 'result']) { window.__n[k] = 0; const o = new MutationObserver(l => { window.__n[k] += l.length; }); o.observe(document.getElementById(k), { childList: true, characterData: true, subtree: true }); } });
  const counts = async () => JSON.stringify(await page.evaluate(() => new Promise(r => setTimeout(() => r(window.__n), 50))));
  await page.goto(URL); await typeInto(page, 'bill', 'abc'); await typeInto(page, 'tip', '1x'); await page.keyboard.press('Tab'); await watch();
  await page.keyboard.type('12345'); for (let i = 0; i < 5; i++) await page.keyboard.press('Backspace'); await page.keyboard.type('4');
  console.log('  2 errors showing, typed 12345, 5 backspaces, 4 in people: changes', await counts(), '(people-error expected to change: empty->msg->empty)');
  await page.goto(URL); await typeInto(page, 'bill', '100.00'); await typeInto(page, 'tip', '18'); await typeInto(page, 'people', '4'); await watch();
  await page.click('#bill'); await page.keyboard.press('End'); await page.keyboard.press('Backspace'); await page.keyboard.type('0'); // 100.0 -> 100.00
  for (let i = 0; i < 6; i++) await page.keyboard.press('Tab'); await page.click('h1'); await page.click('#tip'); await page.keyboard.press('Home'); await page.keyboard.type('0'); await page.keyboard.press('End'); await page.keyboard.type(' ');
  console.log('  result showing; bill 100.00->100.0->100.00, tabbing, tip 18->018->"018 ": changes', await counts(), fmt(await state(page)));
  await page.goto(URL); await typeInto(page, 'bill', '100.00'); await typeInto(page, 'tip', '18'); await typeInto(page, 'people', '4'); await watch();
  await page.click('#bill'); await page.keyboard.press('End'); await page.keyboard.type(' '); await page.keyboard.press('Home'); await page.keyboard.type('0');
  console.log('  result showing; bill "100.00" -> "100.00 " -> "0100.00 " (same amount): changes', await counts());
  // ---- C7
  console.log('== C7');
  console.log('  CSP tag exact:', src.includes(`<meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline'; script-src 'unsafe-inline'">`));
  for (const w of ['localStorage', 'sessionStorage', 'indexedDB', 'document.cookie', 'caches', 'cookie', 'navigator.sendBeacon', 'history.', 'location', 'postMessage', 'BroadcastChannel', 'serviceWorker', 'eval', 'innerHTML', 'new Function']) console.log(`  source count ${w}: ${src.split(w).length - 1}`);
  await page.goto(URL); errs.length = 0; const before = reqs.length;
  const probes = await page.evaluate(async () => { const out = {}; const t = async (k, f) => { try { out[k] = 'NOT BLOCKED: ' + await f(); } catch (e) { out[k] = 'blocked: ' + e.name + ': ' + e.message; } };
    await t('fetch https', () => fetch('https://example.com').then(r => r.status));
    await t('fetch http', () => fetch('http://example.com').then(r => r.status));
    await t('xhr', () => new Promise((res, rej) => { const x = new XMLHttpRequest(); x.open('GET', 'https://example.com'); x.onload = () => res(x.status); x.onerror = () => rej(new Error('xhr error')); x.send(); }));
    await t('img', () => new Promise((res, rej) => { const i = new Image(); i.onload = () => res('loaded'); i.onerror = () => rej(new Error('img error')); i.src = 'https://example.com/x.png'; }));
    await t('beacon', async () => { const ok = navigator.sendBeacon('https://example.com', 'x'); if (!ok) throw new Error('sendBeacon returned false'); return ok; });
    await t('websocket', () => new Promise((res, rej) => { try { const w = new WebSocket('wss://example.com'); w.onopen = () => res('open'); w.onerror = () => rej(new Error('ws error')); } catch (e) { rej(e); } }));
    await t('eval', async () => eval('1+1'));
    await t('localStorage', async () => { localStorage.setItem('a', '1'); return localStorage.length; });
    out.cookie = JSON.stringify(document.cookie); out.lsLen = (() => { try { return localStorage.length; } catch (e) { return e.name; } })(); out.ssLen = (() => { try { return sessionStorage.length; } catch (e) { return e.name; } })();
    try { out.idb = JSON.stringify(await indexedDB.databases()); } catch (e) { out.idb = e.name; }
    try { out.caches = JSON.stringify(await caches.keys()); } catch (e) { out.caches = e.name + ': ' + e.message; }
    return out; });
  await page.waitForTimeout(1500);
  for (const k of Object.keys(probes)) console.log('  ' + k + ' => ' + probes[k]);
  console.log('  network requests seen after probes:', JSON.stringify(reqs.slice(before)));
  console.log('  console during probes:', JSON.stringify(errs.slice(0, 12)));
  // reload clears
  await page.goto(URL); await page.evaluate(() => { try { localStorage.clear(); } catch (e) {} });
  await typeInto(page, 'bill', '100.00'); await typeInto(page, 'tip', '18'); await typeInto(page, 'people', '4');
  await page.reload(); await page.waitForTimeout(800);
  console.log('  after reload:', JSON.stringify(await page.evaluate(() => [...document.querySelectorAll('input')].map(i => i.value))), fmt(await state(page)));
  await typeInto(page, 'bill', 'abc'); await typeInto(page, 'tip', '18'); await typeInto(page, 'people', '4');
  await page.keyboard.press('F5'); await page.waitForTimeout(1000);
  console.log('  after F5 with an error showing:', JSON.stringify(await page.evaluate(() => [...document.querySelectorAll('input')].map(i => i.value))), fmt(await state(page)));
  await typeInto(page, 'bill', '100.00'); await typeInto(page, 'tip', '18'); await typeInto(page, 'people', '4');
  await page.goto('about:blank'); await page.goBack(); await page.waitForTimeout(800);
  console.log('  after leave to about:blank and Back:', JSON.stringify(await page.evaluate(() => [...document.querySelectorAll('input')].map(i => i.value))), fmt(await state(page)));
  await typeInto(page, 'bill', '100.00'); await typeInto(page, 'tip', '18'); await typeInto(page, 'people', '4');
  await page.goto(URL + '?bill=5&tip=5&people=5#bill=5'); console.log('  URL with query and hash:', JSON.stringify(await page.evaluate(() => [...document.querySelectorAll('input')].map(i => i.value))), fmt(await state(page)));
  console.log('  storage after all use:', JSON.stringify(await page.evaluate(async () => ({ ls: localStorage.length, ss: sessionStorage.length, cookie: document.cookie }))));
  console.log('  page errors over whole run:', JSON.stringify(errs.filter(e => e.startsWith('pageerror'))));
  await b.close();
})().catch(e => { console.error('ERR', e); process.exit(1); });
