const { launch, state, typeInto, URL, path, esc, fmt } = require('./lib');
const fs = require('fs');
(async () => {
  const b = await launch(); const ctx = await b.newContext(); const page = await ctx.newPage();
  const cdp = await ctx.newCDPSession(page); await cdp.send('Network.enable'); const net = {};
  cdp.on('Network.requestWillBeSent', e => { net[e.requestId] = { url: e.request.url, end: 'pending' }; });
  cdp.on('Network.loadingFailed', e => { if (net[e.requestId]) net[e.requestId].end = 'failed blockedReason=' + e.blockedReason + ' error=' + e.errorText; });
  cdp.on('Network.responseReceived', e => { if (net[e.requestId]) net[e.requestId].end = 'response ' + e.response.status; });
  await page.goto(URL);
  const r = await page.evaluate(async () => { const o = {}; try { await fetch('https://example.com'); o.fetch = 'NOT BLOCKED'; } catch (e) { o.fetch = 'blocked: ' + e.message; } o.beacon = navigator.sendBeacon('https://example.com/beacon', 'x'); new Image().src = 'https://example.com/x.png'; return o; });
  await page.waitForTimeout(2500);
  console.log('== C7 probes:', JSON.stringify(r)); console.log(JSON.stringify(Object.values(net), null, 1));
  // paste of control characters
  console.log('== paste of control characters at the ends (clipboard, Ctrl+V)');
  await ctx.grantPermissions(['clipboard-read', 'clipboard-write']);
  await page.goto(URL); await typeInto(page, 'tip', '18'); await typeInto(page, 'people', '4');
  for (const t of ['12.50\u0085', '12.50\u001F', '\u000112.50', '12.50\u007F', '12.50\u0000', '12.50\u200B', '12.50\u2028', '12.50\u000B', '12.50\u000C', '12.50\u009F']) { await page.evaluate(t => navigator.clipboard.writeText(t), t); await page.click('#bill'); await page.keyboard.press('Control+a'); await page.keyboard.press('Control+v'); const held = await page.inputValue('#bill'); const s = await state(page); console.log(`  clipboard [${esc(t)}] -> field holds [${esc(held)}] :: ${s.bill ? 'MSG' : 'no-msg'} / ${s.result.length ? s.result[0] : 'no-result'}`); }
  // which invisible-ish code points at the end are not ignored: scan BMP + some astral through the page (script-set value + input event; the reading code is what is under test)
  console.log('== scan: "12.50"+c for every code point c; list c where page shows result (ignored) by general category, and Cc/Zs/Zl/Zp/Cf/DI not ignored');
  const scan = await page.evaluate(() => { const el = document.getElementById('bill'); const ign = []; const notIgn = []; const inv = /[\p{Cc}\p{Cf}\p{Z}\p{Default_Ignorable_Code_Point}]/u;
    for (let c = 0; c <= 0x10FFFF; c++) { if (c >= 0xD800 && c <= 0xDFFF) continue; if (c > 0x1FFFF && c < 0xE0000) continue; if (c > 0xE0FFF) break; const ch = String.fromCodePoint(c); if (/[0-9.,]/.test(ch)) continue; el.value = '12.50' + ch; if (el.value !== '12.50' + ch) continue; el.dispatchEvent(new Event('input', { bubbles: true })); const res = document.querySelectorAll('#result p').length > 0; const bt = res ? document.querySelector('#result p').textContent : ''; if (res && bt !== 'Bill total: 12.50') ign.push('DIFFERENT AMOUNT U+' + c.toString(16) + ' ' + bt); else if (res) ign.push(c); else if (inv.test(ch)) notIgn.push(c); }
    el.value = ''; el.dispatchEvent(new Event('input', { bubbles: true }));
    const cat = c => { const ch = String.fromCodePoint(c); for (const k of ['Cc', 'Cf', 'Zs', 'Zl', 'Zp', 'Lo', 'Mn', 'Me', 'Mc', 'So', 'Nd', 'No', 'Po', 'Cn', 'Co', 'Lm', 'Sk']) if (new RegExp('\\p{' + k + '}', 'u').test(ch)) return k; return '??'; };
    const group = a => { const g = {}; for (const c of a) { if (typeof c === 'string') { (g.X = g.X || []).push(c); continue; } const k = cat(c); (g[k] = g[k] || []).push(c); } const out = {}; for (const k in g) { const r = []; let s = null, p = null; for (const c of g[k]) { if (typeof c === 'string') { r.push(c); continue; } if (s === null) { s = p = c; } else if (c === p + 1) { p = c; } else { r.push(s === p ? s.toString(16) : s.toString(16) + '-' + p.toString(16)); s = p = c; } } if (s !== null) r.push(s === p ? s.toString(16) : s.toString(16) + '-' + p.toString(16)); out[k] = g[k].length + ': ' + r.join(' ').toUpperCase(); } return out; };
    return { ignored: group(ign), notIgnored: group(notIgn) }; });
  console.log('IGNORED at the end (result shows):'); for (const k in scan.ignored) console.log('  ' + k + ' ' + scan.ignored[k].slice(0, 1500));
  console.log('NOT IGNORED (message shows) among Cc, Cf, Z*, Default_Ignorable:'); for (const k in scan.notIgnored) console.log('  ' + k + ' ' + scan.notIgnored[k].slice(0, 600));
  // other code points that read as digits / marks
  const dig = await page.evaluate(() => { const el = document.getElementById('bill'); const out = []; for (let c = 0x80; c <= 0x1FFFF; c++) { if (c >= 0xD800 && c <= 0xDFFF) continue; const ch = String.fromCodePoint(c); el.value = '1' + ch + '5'; el.dispatchEvent(new Event('input', { bubbles: true })); const p = document.querySelector('#result p'); if (p) out.push('U+' + c.toString(16).toUpperCase() + '=>' + p.textContent.slice(12)); } el.value = ''; el.dispatchEvent(new Event('input', { bubbles: true })); return out; });
  console.log('== scan: "1"+c+"5" accepted for these c (tip 18, people 4):', dig.join(' '));
  await b.close();
  // script blocked while scripting is on: same bytes served with a response header that forbids inline script
  console.log('== same bytes, inline script blocked by a host CSP header (scripting itself is on)');
  const b2 = await launch(); const p2 = await b2.newPage(); const bytes = fs.readFileSync(path);
  await p2.route('http://audit.test/index.html', r => r.fulfill({ status: 200, contentType: 'text/html', headers: { 'Content-Security-Policy': "script-src 'self'" }, body: bytes }));
  await p2.goto('http://audit.test/index.html'); console.log('body innerText:', JSON.stringify(await p2.locator('body').innerText())); await p2.screenshot({ path: 'scriptblocked.png' });
  await b2.close();
})().catch(e => { console.error('ERR', e); process.exit(1); });
