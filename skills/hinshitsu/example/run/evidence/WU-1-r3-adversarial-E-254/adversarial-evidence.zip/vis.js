const { launch, state, typeInto, URL, fmt } = require('./lib');
(async () => { const b = await launch(); const page = await b.newPage({ viewport: { width: 500, height: 330 } });
  for (const [n, t] of [['a', '12.50\u06DD'], ['b', '\u070F\u089012.50\uFFF0\u2065'], ['c', '12.50\u1680']]) { await page.goto(URL); await typeInto(page, 'tip', '18'); await typeInto(page, 'people', '4'); await typeInto(page, 'bill', t); const s = await state(page); console.log(n, s.bill || 'no-msg', s.result[0]); await page.locator('#bill').screenshot({ path: 'vis_' + n + '.png' }); }
  await b.close(); })();
