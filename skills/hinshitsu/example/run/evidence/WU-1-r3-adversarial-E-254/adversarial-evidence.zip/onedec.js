const { launch, state, typeInto, URL, fmt } = require('./lib');
(async () => {
  const b = await launch(); const page = await b.newPage();
  for (const [bill, tip, people] of [['0100.5', '007', '02'], ['12.5', '18', '4'], ['12,5', '18', '4'], ['12.50', '18', '4'], ['0.5', '0', '1'], ['0.1', '0', '1'], ['0.9', '0', '1'], ['1000000.0', '0', '1'], ['999999.9', '0', '1'], ['0.0', '0', '1'], ['12.05', '18', '4'], ['\uFF11\uFF12\uFF0E\uFF15', '18', '4']]) {
    await page.goto(URL);
    await typeInto(page, 'bill', bill); await typeInto(page, 'tip', tip); await typeInto(page, 'people', people);
    console.log(JSON.stringify([await page.inputValue('#bill'), tip, people]), fmt(await state(page)));
  }
  await b.close();
})();
