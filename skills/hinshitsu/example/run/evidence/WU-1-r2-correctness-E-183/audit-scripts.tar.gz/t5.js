// Desktop (headed) Chrome on display :0, driven over its CDP endpoint.
const { chromium, URL_, state, typeIn, leave } = require('./lib');
const J = x => JSON.stringify(x);
(async () => {
  const b = await chromium.connectOverCDP('http://localhost:29229'); const ctx = b.contexts()[0];
  console.log('desktop browser', b.version());
  const page = await ctx.newPage(); const reqs = []; page.on('request', r => reqs.push(r.url()));
  await page.goto(URL_); await page.bringToFront(); await page.waitForTimeout(1000);
  console.log('requests', J(reqs), 'visibility', await page.evaluate(() => document.visibilityState + ' hasFocus=' + document.hasFocus()));
  await typeIn(page, 'bill', '100.00'); await typeIn(page, 'tip', '18'); await typeIn(page, 'people', '4');
  let s = await state(page); console.log('typed 100.00, 18, 4 ->', J(s.result));
  await page.screenshot({ path: 'out/desktop-result.png' });
  await page.reload(); await page.waitForTimeout(500); s = await state(page); console.log('after reload', J(s.val), J(s.result), J(s.err));
  // window/tab switch while a field has the cursor
  await page.click('#bill'); s = await state(page); console.log('clicked empty bill field:', J(s.err), 'active', s.active);
  const other = await ctx.newPage(); await other.goto('about:blank'); await other.bringToFront(); await other.waitForTimeout(700);
  s = await state(page); console.log('after switching to another tab, nothing typed:', J(s.err), 'active', s.active, await page.evaluate(() => document.visibilityState + ' hasFocus=' + document.hasFocus()));
  await page.bringToFront(); await page.waitForTimeout(500); s = await state(page); console.log('back on the page:', J(s.err), 'active', s.active);
  await page.reload(); await typeIn(page, 'tip', '18'); await typeIn(page, 'people', '4'); await typeIn(page, 'bill', '12.');
  s = await state(page); console.log('"12." with cursor in bill:', J(s.err.bill), s.result.length);
  await other.bringToFront(); await other.waitForTimeout(700); s = await state(page); console.log('"12." after switching tab (cursor stays in bill):', J(s.err.bill), 'active', s.active);
  await page.bringToFront(); await page.waitForTimeout(300);
  await page.keyboard.press('Tab'); s = await state(page); console.log('"12." after Tab to tip:', J(s.err.bill));
  await page.keyboard.press('Shift+Tab'); s = await state(page); console.log('"12." after Shift+Tab back into bill (cursor in bill):', J(s.err.bill), 'active', s.active, 'result lines', s.result.length);
  await page.screenshot({ path: 'out/desktop-12dot-refocus.png' });
  await other.close(); await page.close(); await b.close();
})().catch(e => { console.error('SCRIPT ERROR', e); process.exit(1); });
