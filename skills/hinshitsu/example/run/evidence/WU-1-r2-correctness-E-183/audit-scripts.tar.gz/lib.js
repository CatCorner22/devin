const { chromium } = require('/home/ubuntu/pwtools/node_modules/playwright');
const path = require('path');
const FILE = '/home/ubuntu/audit/wt/skills/hinshitsu/example/run/review/index.html';
const URL_ = 'file://' + FILE;
async function launch() {
  return chromium.launch({ executablePath: '/home/ubuntu/.local/bin/google-chrome', headless: true });
}
async function state(page) {
  return page.evaluate(() => ({
    result: Array.from(document.querySelectorAll('#result p')).map(p => p.textContent),
    resultText: document.getElementById('result').textContent,
    err: { bill: document.getElementById('bill-error').textContent, tip: document.getElementById('tip-error').textContent, people: document.getElementById('people-error').textContent },
    val: { bill: bill.value, tip: tip.value, people: people.value },
    invalid: ['bill','tip','people'].filter(n => document.getElementById(n).getAttribute('aria-invalid') === 'true'),
    active: document.activeElement && document.activeElement.id || document.activeElement.tagName
  }));
}
async function typeIn(page, id, text) {
  await page.click('#' + id);
  await page.keyboard.press('Control+A');
  await page.keyboard.press('Delete');
  if (text !== '') await page.keyboard.type(text);
}
async function leave(page) { await page.click('h1'); }
module.exports = { chromium, FILE, URL_, launch, state, typeIn, leave };
