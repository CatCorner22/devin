// C3: the AUDITOR's own arithmetic, compared with the page's own output. Values go into the page's own fields with Playwright fill() (sets the value and fires the page's input event).
const { launch, URL_ } = require('./lib');
const fmt = c => { const s = String(c).padStart(3, '0'); return s.slice(0, -2) + '.' + s.slice(-2); };
function expected(billCents, pct, n) {
  const q = billCents * pct; const tip = (q - q % 100) / 100 + (q % 100 >= 50 ? 1 : 0); const total = billCents + tip;
  const pays = new Array(n).fill(0); let left = total; const each = (total - total % n) / n; for (let i = 0; i < n; i++) { pays[i] = each; left -= each; } for (let i = 0; left > 0; i++, left--) pays[i] += 1;
  const groups = []; for (const p of pays) { const g = groups.find(x => x.c === p); if (g) g.k++; else groups.push({ c: p, k: 1 }); } groups.sort((a, b) => b.c - a.c);
  const lines = ['Bill total: ' + fmt(billCents), 'Tip percent: ' + pct, 'Number of people: ' + n, 'Tip amount: ' + fmt(tip), 'Total with tip: ' + fmt(total)];
  for (const g of groups) lines.push(g.k === 1 ? '1 person pays ' + fmt(g.c) : g.k + ' people pay ' + fmt(g.c) + ' each');
  if (groups.length === 2) lines.push('Your group decides who pays the higher amount.');
  return lines;
}
(async () => {
  const b = await launch(); const page = await (await b.newContext()).newPage(); await page.goto(URL_);
  let cases = 0, mism = 0, sumFail = 0, diffFail = 0; const shown = [];
  let last = {};
  async function one(bill, tip, people, billCents) {
    if (last.bill !== bill) { await page.fill('#bill', bill); last.bill = bill; }
    if (last.tip !== tip) { await page.fill('#tip', tip); last.tip = tip; }
    if (last.people !== people) { await page.fill('#people', people); last.people = people; }
    const got = await page.evaluate(() => ({ lines: Array.from(document.querySelectorAll('#result p')).map(p => p.textContent), errs: ['bill', 'tip', 'people'].map(n => document.getElementById(n + '-error').textContent) }));
    const exp = expected(billCents, parseInt(tip, 10), parseInt(people, 10)); cases++;
    const ok = JSON.stringify(got.lines) === JSON.stringify(exp);
    // independent check of the sum and the spread, from the page's own text
    let sum = 0, min = Infinity, max = -Infinity;
    for (const l of got.lines) { const m = /^(\d+) (?:person pays|people pay) (\d+)\.(\d\d)(?: each)?$/.exec(l); if (m) { const c = parseInt(m[2], 10) * 100 + parseInt(m[3], 10); sum += parseInt(m[1], 10) * c; min = Math.min(min, c); max = Math.max(max, c); } }
    const tl = got.lines.find(l => l.startsWith('Total with tip: ')); const total = tl ? Math.round(parseFloat(tl.slice(16)) * 100) : NaN;
    if (!(sum === total)) sumFail++; if (!(max - min <= 1)) diffFail++;
    if (!ok) { mism++; if (shown.length < 12) shown.push({ typed: [bill, tip, people], page: got.lines, pageErrors: got.errs, auditor: exp }); }
  }
  const t0 = Date.now();
  for (const tip of ['0', '15', '18', '20']) for (let c = 1; c <= 5000; c++) await one(fmt(c), tip, '1', c);
  console.log('sweep 1 (bills 0.01-50.00 step 0.01; tips 0, 15, 18, 20; 1 person): cases so far', cases, 'mismatches', mism, 'sum failures', sumFail, 'spread failures', diffFail);
  for (let n = 1; n <= 12; n++) for (let c = 1; c <= 500; c++) await one(fmt(c), '18', String(n), c);
  console.log('sweep 2 (bills 0.01-5.00 step 0.01; 1-12 people; tip 18): cases so far', cases, 'mismatches', mism, 'sum failures', sumFail, 'spread failures', diffFail);
  const before = mism;
  for (const [bi, ti, pe, c] of [['10.00', '0', '3', 1000], ['1000000.00', '100', '100', 100000000], ['0.01', '0', '100', 1]]) { const m0 = mism; await one(bi, ti, pe, c); console.log('spot ' + JSON.stringify([bi, ti, pe]) + ': ' + (mism === m0 ? 'MATCH' : 'MISMATCH') + ' page=' + JSON.stringify(await page.evaluate(() => Array.from(document.querySelectorAll('#result p')).map(p => p.textContent))) + ' auditor=' + JSON.stringify(expected(c, +ti, +pe))); }
  console.log('TOTAL cases', cases, 'mismatches', mism, 'sum failures', sumFail, 'spread failures', diffFail, 'seconds', Math.round((Date.now() - t0) / 1000));
  console.log('first mismatches:', JSON.stringify(shown, null, 1));
  await b.close();
})().catch(e => { console.error('SCRIPT ERROR', e); process.exit(1); });
