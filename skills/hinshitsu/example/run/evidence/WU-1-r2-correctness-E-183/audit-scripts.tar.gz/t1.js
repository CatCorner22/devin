const { launch, URL_, state, typeIn, leave, FILE } = require('./lib');
const fs = require('fs');
const J = x => JSON.stringify(x);
let fails = 0;
function check(name, ok, detail) { if (!ok) fails++; console.log((ok ? 'PASS ' : 'FAIL ') + name + (detail !== undefined ? ' :: ' + (typeof detail === 'string' ? detail : J(detail)).slice(0, ok ? 400 : 600) : '')); }
(async () => {
  const b = await launch();
  console.log('browser version', b.version());
  // ---------- C1
  {
    const ctx = await b.newContext(); const page = await ctx.newPage();
    const reqs = []; page.on('request', r => reqs.push(r.url()));
    const cdp = await ctx.newCDPSession(page); await cdp.send('Network.enable');
    const cdpReqs = []; cdp.on('Network.requestWillBeSent', e => cdpReqs.push(e.request.url));
    const cons = []; page.on('console', m => cons.push(m.type() + ': ' + m.text())); page.on('pageerror', e => cons.push('pageerror: ' + e.message));
    await page.goto(URL_); await page.waitForTimeout(1500);
    console.log('C1 playwright requests', J(reqs)); console.log('C1 CDP requestWillBeSent', J(cdpReqs)); console.log('C1 console', J(cons));
    check('C1 one request (playwright)', reqs.length === 1, reqs.length);
    check('C1 one request (CDP)', cdpReqs.length === 1, cdpReqs.length);
    const perf = await page.evaluate(() => performance.getEntriesByType('resource').map(e => e.name));
    check('C1 no resource timing entries', perf.length === 0, perf);
    // first open state
    const s0 = await state(page);
    const vis = await page.evaluate(() => ({ guide: guide.hidden, guideText: guide.textContent, fields: fields.hidden, inputs: document.querySelectorAll('input').length, bodyText: document.body.innerText }));
    console.log('first open', J(s0), J(vis.bodyText));
    check('C4 first open: 3 empty fields, guidance, no error, no result', vis.inputs === 3 && s0.val.bill === '' && s0.val.tip === '' && s0.val.people === '' && !vis.guide && s0.resultText === '' && !s0.err.bill && !s0.err.tip && !s0.err.people && s0.invalid.length === 0);
    // ---------- C2 tests typed
    const c2 = [
      ['100.00','18','4', ['Bill total: 100.00','Tip percent: 18','Number of people: 4','Tip amount: 18.00','Total with tip: 118.00','4 people pay 29.50 each']],
      ['0.30','15','1', ['Bill total: 0.30','Tip percent: 15','Number of people: 1','Tip amount: 0.05','Total with tip: 0.35','1 person pays 0.35']],
      ['10.10','15','1', ['Bill total: 10.10','Tip percent: 15','Number of people: 1','Tip amount: 1.52','Total with tip: 11.62','1 person pays 11.62']],
      ['12.25','18','1', ['Bill total: 12.25','Tip percent: 18','Number of people: 1','Tip amount: 2.21','Total with tip: 14.46','1 person pays 14.46']],
      ['0100.5','007','02', ['Bill total: 100.50','Tip percent: 7','Number of people: 2','Tip amount: 7.04','Total with tip: 107.54','2 people pay 53.77 each']],
      ['10.00','0','3', ['Bill total: 10.00','Tip percent: 0','Number of people: 3','Tip amount: 0.00','Total with tip: 10.00','1 person pays 3.34','2 people pay 3.33 each','Your group decides who pays the higher amount.']],
      ['10.01','0','3', ['Bill total: 10.01','Tip percent: 0','Number of people: 3','Tip amount: 0.00','Total with tip: 10.01','2 people pay 3.34 each','1 person pays 3.33','Your group decides who pays the higher amount.']],
      ['1000000.00','100','100', ['Bill total: 1000000.00','Tip percent: 100','Number of people: 100','Tip amount: 1000000.00','Total with tip: 2000000.00','100 people pay 20000.00 each']],
      ['1000000','0','1', ['Bill total: 1000000.00','Tip percent: 0','Number of people: 1','Tip amount: 0.00','Total with tip: 1000000.00','1 person pays 1000000.00']],
      ['999999.99','100','100', ['Bill total: 999999.99','Tip percent: 100','Number of people: 100','Tip amount: 999999.99','Total with tip: 1999999.98','98 people pay 20000.00 each','2 people pay 19999.99 each','Your group decides who pays the higher amount.']],
      ['0.01','0','100', ['Bill total: 0.01','Tip percent: 0','Number of people: 100','Tip amount: 0.00','Total with tip: 0.01','1 person pays 0.01','99 people pay 0.00 each','Your group decides who pays the higher amount.']],
      ['12,50','20','2', ['Bill total: 12.50','Tip percent: 20','Number of people: 2','Tip amount: 2.50','Total with tip: 15.00','2 people pay 7.50 each']],
      ['7','10','1', ['Bill total: 7.00','Tip percent: 10','Number of people: 1','Tip amount: 0.70','Total with tip: 7.70','1 person pays 7.70']],
      ['0.05','10','1', ['Bill total: 0.05','Tip percent: 10','Number of people: 1','Tip amount: 0.01','Total with tip: 0.06','1 person pays 0.06']],
      ['0.04','10','1', ['Bill total: 0.04','Tip percent: 10','Number of people: 1','Tip amount: 0.00','Total with tip: 0.04','1 person pays 0.04']],
      ['  12.50  ','\u00a018\u200b','\ufeff4 ', ['Bill total: 12.50','Tip percent: 18','Number of people: 4','Tip amount: 2.25','Total with tip: 14.75','3 people pay 3.69 each','1 person pays 3.68','Your group decides who pays the higher amount.']],
      ['\uff11\uff12\uff0e\uff15\uff10','\uff11\uff18','\uff14', ['Bill total: 12.50','Tip percent: 18','Number of people: 4','Tip amount: 2.25','Total with tip: 14.75','3 people pay 3.69 each','1 person pays 3.68','Your group decides who pays the higher amount.']],
      ['\uff11\uff12\uff0c\uff15\uff10','18','4', ['Bill total: 12.50','Tip percent: 18','Number of people: 4','Tip amount: 2.25','Total with tip: 14.75','3 people pay 3.69 each','1 person pays 3.68','Your group decides who pays the higher amount.']],
      ['\u0661\u0662\u066b\u0665\u0660','\u0661\u0668','\u0664', ['Bill total: 12.50','Tip percent: 18','Number of people: 4','Tip amount: 2.25','Total with tip: 14.75','3 people pay 3.69 each','1 person pays 3.68','Your group decides who pays the higher amount.']],
      ['\u06f1\u06f2.\u06f5\u06f0','\u06f1\u06f8','\u06f4', ['Bill total: 12.50','Tip percent: 18','Number of people: 4','Tip amount: 2.25','Total with tip: 14.75','3 people pay 3.69 each','1 person pays 3.68','Your group decides who pays the higher amount.']],
    ];
    for (const [bi, ti, pe, exp] of c2) {
      await typeIn(page, 'bill', bi); await typeIn(page, 'tip', ti); await typeIn(page, 'people', pe);
      const s = await state(page);
      const ok2 = J(s.result) === J(exp) && !s.err.bill && !s.err.tip && !s.err.people; check('C2/C3 typed ' + J([bi, ti, pe]), ok2, ok2 ? s.result.join(' | ') : { got: s.result, err: s.err });
    }
    // result recomputed on every change: type char by char
    await typeIn(page, 'bill', '100.00'); await typeIn(page, 'tip', '18'); await typeIn(page, 'people', '');
    const steps = [];
    for (const ch of ['4', '0', 'Backspace', 'Backspace', '3']) { await page.keyboard.press(ch); const s = await state(page); steps.push([ch, s.val.people, s.result.slice(5), s.err.people]); }
    console.log('recompute on each key in people:', J(steps));
    await ctx.close();
  }
  // ---------- C4 invalid inputs
  {
    const ctx = await b.newContext(); const page = await ctx.newPage();
    const good = { bill: '100.00', tip: '18', people: '4' };
    const bad = {
      bill: ['', 'abc', '12a', '1,000.00', '1.000,00', '1e3', '10.', '10,', '.5', ',5', '$12', '12$', '\u20ac12.50', '12.50 USD', '-5', '-0.01', '0', '0.0', '0.00', '00', '1000000.01', '1000001', '10000000', '99999999999999999999999', '1.234', '1,234', '0.001', '1..2', '1.2.3', '1 000', '+5', '12.5.', '1/2', '0x10', 'Infinity', 'NaN', '1_000', "1'000", '12 .50', '12. 50'],
      tip: ['', 'abc', '101', '1000', '-1', '18.0', '18,5', '1e1', '+4', '4.', '18%', '1 8', '0x1', '.5', '00101', '99999999999999999999'],
      people: ['', 'abc', '0', '00', '101', '1000', '-1', '18.0', '18,5', '1e1', '+4', '4.', '4,', '2 people', '1 0', '99999999999999999999']
    };
    const groups = {}; let c4n = 0, c4fail = 0;
    for (const f of Object.keys(bad)) for (const v of bad[f]) {
      await page.goto(URL_);
      for (const g of Object.keys(good)) if (g !== f) await typeIn(page, g, good[g]);
      await page.click('#' + f);
      if (v === '') { await page.keyboard.type('1'); await page.keyboard.press('Backspace'); } else await page.keyboard.type(v);
      const s1 = await state(page);
      await leave(page);
      const s2 = await state(page);
      const waitingCase = f === 'bill' && /^\d+[.,]$/.test(v);
      const ok = s2.err[f] !== '' && s2.resultText === '' && s1.resultText === '' && (waitingCase ? s1.err[f] === '' : s1.err[f] !== '') && s2.invalid.includes(f) && Object.keys(good).every(g => g === f || s2.err[g] === '');
      c4n++; if (!ok) { c4fail++; check('C4 ' + f + ' ' + J(v), ok, { focused: s1.err[f], left: s2.err[f], result: s2.resultText }); }
      const key = f + ' :: with the cursor in the field: ' + (s1.err[f] ? J(s1.err[f]) : 'no message') + ' :: after leaving: ' + J(s2.err[f]) + ' :: result: ' + (s2.resultText ? 'SHOWN' : 'none'); (groups[key] = groups[key] || []).push(v);
    }
    for (const k of Object.keys(groups)) console.log('C4 ' + k + ' :: ' + groups[k].length + ' inputs: ' + J(groups[k]));
    check('C4 invalid inputs: ' + c4n + ' typed, each got a message below its own field, no result, no message on another field', c4fail === 0, c4fail + ' failures');
    // empty field left without typing
    for (const f of ['bill', 'tip', 'people']) {
      await page.goto(URL_); await page.click('#' + f); const s1 = await state(page); await page.keyboard.press('Tab'); const s2 = await state(page);
      check('C4 ' + f + ' focused only: no message; left empty with Tab: message', s1.err[f] === '' && s2.err[f] !== '' && s2.resultText === '', s2.err[f]);
    }
    // incomplete: only bill typed valid
    await page.goto(URL_); await typeIn(page, 'bill', '12.50'); let s = await state(page);
    check('C4 incomplete: bill valid, others untouched: no message, no result', !s.err.bill && !s.err.tip && !s.err.people && s.resultText === '', { err: s.err, lines: s.result.length, invalid: s.invalid, active: s.active });
    // 12. while focused with others valid, then leave, then come back
    await page.goto(URL_); await typeIn(page, 'tip', '18'); await typeIn(page, 'people', '4'); await page.click('#bill');
    const trace = [];
    for (const ch of '12.50') { await page.keyboard.type(ch); s = await state(page); trace.push([s.val.bill, s.err.bill, s.result.length]); }
    console.log('typing 12.50 key by key [value, bill error, result lines]:', J(trace));
    await typeIn(page, 'bill', '12.'); s = await state(page); check('C4 "12." focused: no message, no result', s.err.bill === '' && s.resultText === '' && s.invalid.length === 0, { err: s.err, lines: s.result.length, invalid: s.invalid, active: s.active });
    await page.keyboard.press('Tab'); s = await state(page); check('C4 "12." after Tab away: message, no result', s.err.bill !== '' && s.resultText === '', { err: s.err, lines: s.result.length, invalid: s.invalid, active: s.active });
    await page.click('#bill'); s = await state(page); console.log('"12." after clicking back into bill (cursor in bill, no key pressed): bill message ' + J(s.err.bill) + ', invalid ' + J(s.invalid) + ', active ' + s.active);
    await page.keyboard.type('5'); s = await state(page); check('C4 "12.5" after return: result', s.result.length > 0 && s.err.bill === '', { err: s.err, lines: s.result.length, invalid: s.invalid, active: s.active });
    await typeIn(page, 'bill', '\uff11\uff12\uff0e'); s = await state(page); check('C4 full-width "12." focused: no message, no result', s.err.bill === '' && s.resultText === '', { err: s.err, lines: s.result.length, invalid: s.invalid, active: s.active });
    await typeIn(page, 'bill', '0.'); s = await state(page); console.log('"0." focused: bill message ' + J(s.err.bill) + ', result lines ' + s.result.length);
    const tr2 = []; await typeIn(page, 'bill', '');
    for (const ch of '0.05') { await page.keyboard.type(ch); s = await state(page); tr2.push([s.val.bill, s.err.bill, s.result.length]); }
    console.log('typing 0.05 key by key:', J(tr2));
    // error -> fix -> result; result -> error clears result
    await typeIn(page, 'bill', 'abc'); s = await state(page); const e1 = s.err.bill; await typeIn(page, 'bill', '20'); s = await state(page);
    check('C4 error then valid: message cleared, result shows', e1 !== '' && s.err.bill === '' && s.result.length === 6 && s.invalid.length === 0, { err: s.err, lines: s.result.length, invalid: s.invalid, active: s.active });
    await typeIn(page, 'tip', 'x'); s = await state(page); check('C4 result then error: result cleared', s.resultText === '' && s.err.tip !== '', { err: s.err, lines: s.result.length, invalid: s.invalid, active: s.active });
    // paste
    await typeIn(page, 'tip', '15');
    await page.click('#bill'); await page.keyboard.press('Control+A'); await page.keyboard.insertText('45,5'); s = await state(page);
    check('insertText (paste-like) 45,5 recomputes', s.result[0] === 'Bill total: 45.50', s.result);
    await ctx.close();
  }
  // ---------- over-acceptance and invisible characters
  {
    const ctx = await b.newContext(); const page = await ctx.newPage();
    const probes = [
      ['bill', '\u200e12.50'], ['bill', '12.50\u200f'], ['bill', '\u202a12.50\u202c'], ['bill', '\u206612.50\u2069'], ['bill', '12.50\u00ad'], ['bill', '\u061c12.50'], ['bill', '12.50\u2063'], ['bill', '\u180e12.50'], ['bill', '\ufe0f12.50'],
      ['bill', '\u200b12.50\u200d'], ['bill', '\u206012.50\ufeff'], ['bill', '\u300012.50\u2003'], ['bill', '\t12.50\t'],
      ['tip', '\u200e18'], ['people', '4\u200f'],
      ['bill', '\u2460'], ['bill', '1\u00b2'], ['bill', '\u2488\u2464'], ['bill', '12\u202450'], ['bill', '12\ufe5250'], ['bill', '\ud835\udfcf\ud835\udfd0'], ['bill', '\u32bf'], ['bill', '\u0967\u0968'],
      ['tip', '\u00b2'], ['tip', '\u2473'], ['tip', '\u2075'], ['people', '\u2462'], ['people', '\u2082'], ['people', '\u0969'], ['tip', '\u00bd'], ['tip', '\u2167'],
      ['bill', '12\u066c500'], ['bill', '\u0661\u0662.\u0665'], ['bill', '1\u06f2,5'], ['bill', '12\u3002' + '50'], ['bill', '12\uff6150']
    ];
    for (const [f, v] of probes) {
      await page.goto(URL_); await typeIn(page, 'bill', '100.00'); await typeIn(page, 'tip', '18'); await typeIn(page, 'people', '4');
      await page.click('#' + f); await page.keyboard.press('Control+A'); await page.keyboard.insertText(v); await leave(page);
      const s = await state(page);
      const cps = Array.from(v).map(c => 'U+' + c.codePointAt(0).toString(16).toUpperCase().padStart(4, '0')).join(' ');
      console.log('PROBE ' + f + ' [' + cps + '] -> ' + (s.resultText ? 'ACCEPTED, shows ' + J(s.result[{ bill: 0, tip: 1, people: 2 }[f]]) : 'REJECTED with a message'));
    }
    await ctx.close();
  }
  await b.close();
  console.log('FAILS', fails);
})().catch(e => { console.error('SCRIPT ERROR', e); process.exit(1); });
