const { launch, URL_, state, typeIn, leave, FILE } = require('./lib');
const fs = require('fs');
const J = x => JSON.stringify(x);
let fails = 0;
function check(name, ok, detail) { if (!ok) fails++; console.log((ok ? 'PASS ' : 'FAIL ') + name + (detail !== undefined ? ' :: ' + (typeof detail === 'string' ? detail : J(detail)).slice(0, ok ? 400 : 600) : '')); }
const measure = () => {
  const w = window.innerWidth, cw = document.documentElement.clientWidth; let worst = null;
  for (const el of document.querySelectorAll('*')) { const r = el.getBoundingClientRect(); if (r.width > w + 0.01 || r.right > w + 0.01 || r.left < -0.01) { if (!worst || r.right > worst.right) worst = { tag: el.tagName, id: el.id, left: r.left, right: r.right, width: r.width }; } }
  const before = window.scrollX; window.scrollTo(10000, 0); const sx = window.scrollX; window.scrollTo(before, 0);
  return { innerWidth: w, clientWidth: cw, docScrollWidth: document.documentElement.scrollWidth, bodyScrollWidth: document.body.scrollWidth, scrollXAfterScrollRight: sx, offender: worst };
};
(async () => {
  const b = await launch();
  // ---------- C5 widths
  for (const w of [360, 768, 1280]) {
    const ctx = await b.newContext({ viewport: { width: w, height: 900 } }); const page = await ctx.newPage(); await page.goto(URL_);
    const run = async (label, shot) => { const m = await page.evaluate(measure); const okw = m.docScrollWidth <= m.innerWidth && m.scrollXAfterScrollRight === 0 && !m.offender; check('C5 width ' + w + ' ' + label, okw, okw ? 'page width ' + m.docScrollWidth + ', scrollX after scrolling right ' + m.scrollXAfterScrollRight + ', elements past the window 0' : m); if (shot) await page.screenshot({ path: 'out/w' + w + '-' + shot + '.png', fullPage: true }); };
    await run('first open', 'first');
    await typeIn(page, 'bill', '1,000.00'); await typeIn(page, 'tip', '18.0'); await typeIn(page, 'people', '0'); await leave(page);
    await run('3 errors', 'errors');
    await typeIn(page, 'bill', '999999.99'); await typeIn(page, 'tip', '100'); await typeIn(page, 'people', '100'); await leave(page);
    await run('2-line result, largest values', 'result');
    await typeIn(page, 'bill', '100.00'); await typeIn(page, 'tip', '18'); await typeIn(page, 'people', '4'); await leave(page);
    await run('1-line result', 'result1');
    await typeIn(page, 'bill', '9'.repeat(300)); await typeIn(page, 'tip', 'W'.repeat(300)); await typeIn(page, 'people', '1'.repeat(300)); await leave(page);
    await run('300-character values in each field', 'long');
    await ctx.close();
  }
  // ---------- C5 markup
  {
    const ctx = await b.newContext(); const page = await ctx.newPage(); await page.goto(URL_);
    const m = await page.evaluate(() => ['bill', 'tip', 'people'].map(n => { const i = document.getElementById(n); const l = document.querySelector('label[for="' + n + '"]'); const r = l.getBoundingClientRect(); const e = document.getElementById(n + '-error');
      return { id: n, label: l.textContent, labelVisible: r.width > 0 && r.height > 0 && getComputedStyle(l).visibility === 'visible' && getComputedStyle(l).display !== 'none', labelsProp: i.labels.length, type: i.type, inputmode: i.getAttribute('inputmode'), autocomplete: i.getAttribute('autocomplete'), describedby: i.getAttribute('aria-describedby'), errRole: e.getAttribute('role'), errTag: e.tagName }; }));
    console.log('markup', J(m));
    const r = await page.evaluate(() => ({ role: result.getAttribute('role'), live: result.getAttribute('aria-live'), alerts: document.querySelectorAll('[role=alert]').length, errors: document.querySelectorAll('p.error').length }));
    console.log('result/alerts', J(r));
    check('C5 labels', m.every(x => x.labelVisible && x.labelsProp === 1) && m[0].label === 'Bill total, tax included', m.map(x => x.label));
    check('C5 inputmode', m[0].inputmode === 'decimal' && m[1].inputmode === 'numeric' && m[2].inputmode === 'numeric');
    check('C5 roles', m.every(x => x.errRole === 'alert' && x.errTag === 'P') && r.role === 'status' && r.alerts === 3 && r.errors === 3);
    check('C7 autocomplete off on each field', m.every(x => x.autocomplete === 'off'));
    // mutation counts
    await page.evaluate(() => { window.__mut = { 'bill-error': 0, 'tip-error': 0, 'people-error': 0, result: 0 }; for (const id of Object.keys(window.__mut)) new MutationObserver(recs => { window.__mut[id] += recs.length; }).observe(document.getElementById(id), { childList: true, characterData: true, subtree: true, attributes: true }); });
    const mut = async () => { const v = await page.evaluate(() => { const c = Object.assign({}, window.__mut); for (const k in window.__mut) window.__mut[k] = 0; return c; }); return v; };
    await typeIn(page, 'bill', 'abc'); await leave(page); let c = await mut(); console.log('mutations after typing "abc" in bill and leaving', J(c));
    await typeIn(page, 'tip', '18'); c = await mut(); check('C5 bill error shown; type "18" in tip: 0 changes in bill-error and result', c['bill-error'] === 0 && c.result === 0, c);
    await typeIn(page, 'people', '4'); await leave(page); c = await mut(); check('C5 bill error shown; type "4" in people and leave: 0 changes in bill-error, tip-error, result', c['bill-error'] === 0 && c['tip-error'] === 0 && c.result === 0, c);
    await typeIn(page, 'tip', 'x'); await leave(page); await mut();
    await typeIn(page, 'people', '12'); await leave(page); c = await mut(); check('C5 bill and tip errors shown; type "12" in people: 0 changes in both error paragraphs and result', c['bill-error'] === 0 && c['tip-error'] === 0 && c.result === 0, c);
    await typeIn(page, 'bill', '100.00'); await typeIn(page, 'tip', '18'); await typeIn(page, 'people', '4'); await mut();
    await page.click('#people'); await page.keyboard.press('Home'); await page.keyboard.type('0'); let s = await state(page); c = await mut();
    check('C5 result shown; people "4" -> "04" (same result text): 0 changes anywhere', s.val.people === '04' && Object.values(c).every(n => n === 0), c);
    await page.click('#bill'); await page.keyboard.press('End'); await page.keyboard.press('Backspace'); s = await state(page); c = await mut();
    check('C5 result shown; bill "100.00" -> "100.0" (same result text): 0 changes anywhere', s.val.bill === '100.0' && Object.values(c).every(n => n === 0), c);
    await page.click('#tip'); await page.keyboard.press('Tab'); await page.keyboard.press('Shift+Tab'); await leave(page); c = await mut();
    check('C5 focus and blur with no edit: 0 changes anywhere', Object.values(c).every(n => n === 0), c);
    await page.click('#tip'); await page.keyboard.press('End'); await page.keyboard.type('0'); c = await mut(); s = await state(page);
    console.log('result changes when tip 18 -> 180 (expected: result cleared, tip error written)', J(c), J(s.err));
    await ctx.close();
  }
  // ---------- C6 JavaScript off
  {
    const ctx = await b.newContext({ javaScriptEnabled: false, viewport: { width: 768, height: 600 } }); const page = await ctx.newPage(); await page.goto(URL_);
    const text = await page.locator('body').innerText();
    const vis = { guide: await page.locator('#guide').isVisible(), fields: await page.locator('#fields').isVisible(), bill: await page.locator('#bill').isVisible(), tip: await page.locator('#tip').isVisible(), people: await page.locator('#people').isVisible(), labels: await page.locator('label').evaluateAll(ls => ls.filter(l => l.getClientRects().length > 0).length), noscript: await page.locator('noscript').isVisible() };
    await page.screenshot({ path: 'out/nojs.png' });
    console.log('C6 body innerText', J(text), J(vis));
    check('C6 JavaScript off: sentence shown, no guidance, no field', text === 'Split the bill\n\nThis calculator needs JavaScript. Turn JavaScript on in your browser, then reload this page.' && !vis.guide && !vis.fields && !vis.bill && !vis.tip && !vis.people && vis.labels === 0, vis);
    await ctx.close();
  }
  // ---------- C7
  {
    const ctx = await b.newContext(); const page = await ctx.newPage();
    const reqs = []; page.on('request', r => reqs.push(r.url())); const cons = []; page.on('console', m => cons.push(m.type() + ': ' + m.text()));
    await page.goto(URL_);
    await page.evaluate(() => { window.__csp = []; document.addEventListener('securitypolicyviolation', e => window.__csp.push({ blockedURI: e.blockedURI, violatedDirective: e.violatedDirective, effectiveDirective: e.effectiveDirective })); });
    const res = await page.evaluate(() => fetch('https://example.com').then(r => 'RESOLVED status ' + r.status, e => 'REJECTED ' + e.name + ': ' + e.message));
    const csp = await page.evaluate(() => window.__csp);
    console.log('C7 fetch result:', res); console.log('C7 securitypolicyviolation events:', J(csp)); console.log('C7 console:', J(cons)); console.log('C7 requests seen:', J(reqs));
    check('C7 fetch blocked by the policy', res.startsWith('REJECTED') && csp.length === 1 && reqs.length === 1, res);
    const more = await page.evaluate(async () => { const out = {}; out.xhr = await new Promise(r => { const x = new XMLHttpRequest(); x.onerror = () => r('error'); x.onload = () => r('load'); try { x.open('GET', 'https://example.com'); x.send(); } catch (e) { r('threw ' + e.name); } });
      out.img = await new Promise(r => { const i = new Image(); i.onload = () => r('load'); i.onerror = () => r('error'); i.src = 'https://example.com/x.png'; });
      out.beacon = (() => { try { return navigator.sendBeacon('https://example.com', 'x'); } catch (e) { return 'threw ' + e.name; } })();
      out.ws = await new Promise(r => { try { const w = new WebSocket('wss://example.com'); w.onerror = () => r('error'); w.onopen = () => r('open'); } catch (e) { r('threw ' + e.name); } });
      await new Promise(r => setTimeout(r, 300)); out.violations = window.__csp.length; return out; });
    console.log('C7 other channels (XHR, image, beacon, WebSocket):', J(more), 'requests seen:', J(reqs));
    const store = await page.evaluate(() => { const o = {}; try { o.localStorage = localStorage.length; } catch (e) { o.localStorage = 'threw ' + e.name; } try { o.sessionStorage = sessionStorage.length; } catch (e) { o.sessionStorage = 'threw ' + e.name; } o.cookie = document.cookie; return o; });
    console.log('C7 storage after use:', J(store));
    // reload clears
    await typeIn(page, 'bill', '100.00'); await typeIn(page, 'tip', '18'); await typeIn(page, 'people', '4'); let s = await state(page); console.log('before reload', J(s.val), s.result.length + ' result lines');
    await page.reload(); s = await state(page);
    check('C7 reload clears every field (and result, errors)', s.val.bill === '' && s.val.tip === '' && s.val.people === '' && s.resultText === '' && !s.err.bill && !s.err.tip && !s.err.people, s.val);
    await typeIn(page, 'bill', 'abc'); await typeIn(page, 'tip', ''); await typeIn(page, 'people', '4'); await leave(page);
    await page.reload(); s = await state(page);
    check('C7 reload from the error state clears fields and messages', s.val.bill === '' && s.val.tip === '' && s.val.people === '' && !s.err.bill && !s.err.tip && s.invalid.length === 0, { val: s.val, err: s.err });
    // back/forward
    await typeIn(page, 'bill', '55'); await typeIn(page, 'tip', '10'); await typeIn(page, 'people', '2');
    await page.goto('about:blank'); await page.goBack(); await page.waitForTimeout(300); s = await state(page);
    check('C7 back button returns to 3 empty fields', s.val.bill === '' && s.val.tip === '' && s.val.people === '' && s.resultText === '', s.val);
    await ctx.close();
  }
  // ---------- function-level calls of the page's own functions (script branches)
  {
    const ctx = await b.newContext(); const page = await ctx.newPage(); await page.goto(URL_);
    const r = await page.evaluate(() => ({
      split_exact: splitBill(10000, 18, 4), split_remainder: splitBill(1000, 0, 3), split_half: splitBill(30, 15, 1), split_below_half: splitBill(29, 15, 1), split_max: splitBill(100000000, 100, 100), split_min: splitBill(1, 0, 100),
      plain: [plain('  12 '), plain('\uff11\uff12\uff0e\uff15'), plain('\u0661\u066b\u0665'), plain('\u06f7'), plain('\u200b7\u2060'), plain('')].map(s => s + '|' + s.length),
      amt: { empty: readAmount('', true), ok0: readAmount('7', false), ok1: readAmount('7.5', false), ok2: readAmount('7,05', false), waitT: readAmount('7.', true), waitF: readAmount('7.', false), bad: readAmount('x', true), lead: readAmount('0007.10', false), long: readAmount('12345678', false), zero: readAmount('0.00', false), max: readAmount('1000000.00', false), maxm1: readAmount('999999.99', false), over: readAmount('1000000.01', false) },
      whole: { empty: readWhole('', 0, 100, 'E'), bad: readWhole('1.0', 0, 100, 'E'), long: readWhole('1000', 0, 100, 'E'), lead: readWhole('0007', 0, 100, 'E'), lo: readWhole('0', 1, 100, 'E'), hi: readWhole('101', 0, 100, 'E'), min: readWhole('0', 0, 100, 'E'), max: readWhole('100', 1, 100, 'E') },
      money: [money(0), money(5), money(10), money(99), money(100), money(123456), money(200000000)],
      payLine: [payLine({ count: 1, cents: 334 }), payLine({ count: 2, cents: 333 })],
      windowSplit: window.splitBill === splitBill
    }));
    for (const k of Object.keys(r)) console.log('FN ' + k + ' ' + J(r[k]));
    await ctx.close();
  }
  await b.close();
  console.log('FAILS', fails);
})().catch(e => { console.error('SCRIPT ERROR', e); process.exit(1); });
