const { launch, URL_, state, typeIn, leave } = require('./lib');
const J = x => JSON.stringify(x);
(async () => {
  const b = await launch(); const ctx = await b.newContext(); const page = await ctx.newPage(); await page.goto(URL_);
  await typeIn(page, 'bill', 'abc'); await typeIn(page, 'tip', ''); await typeIn(page, 'people', '4'); await leave(page);
  await page.evaluate(() => { window.__marker = 1; });
  let s = await state(page); console.log('error state before reload', J(s.val), J(s.err));
  await page.reload(); s = await state(page);
  console.log('after page.reload(): marker', await page.evaluate(() => typeof window.__marker), J(s));
  // typing immediately at DOMContentLoaded, before pageshow
  const p2 = await ctx.newPage(); await p2.goto(URL_, { waitUntil: 'commit' }); 
  await p2.evaluate(() => { window.__ps = 0; window.addEventListener('pageshow', () => window.__ps++); return document.readyState; }).then(r => console.log('readyState right after commit:', r));
  await b.close();
})().catch(e => { console.error('SCRIPT ERROR', e); process.exit(1); });
