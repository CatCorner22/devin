// Real window switch in desktop Chrome. Step 1 sets up and disconnects (so no focus emulation stays on); step 2 reads.
const { chromium, URL_, state } = require('./lib');
const J = x => JSON.stringify(x);
(async () => {
  const b = await chromium.connectOverCDP('http://localhost:29229'); const ctx = b.contexts()[0];
  if (process.argv[2] === 'setup') {
    const page = await ctx.newPage(); await page.goto(URL_ + '#audit-blur'); await page.bringToFront();
    if (process.argv[3]) { await page.fill('#tip', '18'); await page.fill('#people', '4'); await page.click('#bill'); await page.keyboard.type(process.argv[3]); } else await page.click('#bill');
    await page.evaluate(() => { window.__ev = []; window.addEventListener('blur', () => window.__ev.push('window blur')); bill.addEventListener('blur', () => window.__ev.push('bill blur, activeElement=' + (document.activeElement.id || document.activeElement.tagName))); });
    console.log('setup', J(await state(page)));
  } else {
    const page = ctx.pages().find(p => p.url().endsWith('#audit-blur'));
    const s = await page.evaluate(() => ({ ev: window.__ev, hasFocus: document.hasFocus(), billError: document.getElementById('bill-error').textContent, active: document.activeElement.id, value: bill.value, invalid: bill.getAttribute('aria-invalid') }));
    console.log('read', J(s));
    if (process.argv[2] === 'close') await page.close();
  }
  await b.close();
})().catch(e => { console.error('SCRIPT ERROR', e); process.exit(1); });
